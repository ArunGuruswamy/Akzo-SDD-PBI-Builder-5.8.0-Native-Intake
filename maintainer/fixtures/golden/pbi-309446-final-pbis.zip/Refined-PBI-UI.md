# Measurement validation — Refined PBI: Shared Angular UI

Status: Development-Ready

- PBI number: 309446. Local draft identifier: pbi-309446-measurement-validation-20261112165401179-0cc97a2c-UI (no Azure DevOps work item was created).
- Shared requirement: PBI 309446, playbook/pbis/pbi-309446-measurement-validation-20261112165401179-0cc97a2c/REQUEST.md
- Development target: DAB + UI
- Related PBIs: Refined-PBI-DAB.md
- Generated from pbi-state.json by Akzo SDD PBI Builder 5.8.0.

## Description

Validate measurements before saving

## Original acceptance criteria (as submitted)

1. Given an invalid value, when it is saved, then the save is rejected with a clear message.

## Business requirements

### BR-1 (rev 1)

A measurement with an invalid value is rejected with a clear message

- Context: Measurement, create, all business units
- Enforced today by: application (CreateMeasurementHandler)
- Development action: implement
- Path cdms: not-applicable — CDMS is a reference for this target
- Path dab: bypasses (EV-6)
- Path ui: reaches (EV-7)
- Decision: DEC-1

### BR-2 (rev 1)

The saved measurement shows which instrument measured it

- Context: Measurement, display
- Enforced today by: application (MeasurementComponent)
- Development action: implement
- Path cdms: not-applicable — CDMS is a reference for this target
- Path dab: not-applicable — Display only
- Path ui: reaches (EV-7)
- Decision: DEC-1

## Acceptance criteria

- AC-1 (positive; BR-1): Given a valid measurement, when it is saved, then it is stored
- AC-2 (negative; BR-1): Given an invalid value, when it is saved, then the save is rejected with a clear message
- AC-3 (positive; BR-2): Given a saved measurement, when it is shown, then the instrument is displayed
- AC-4 (negative; BR-2): Given a measurement without an instrument, when it is shown, then a placeholder is displayed

## Technical implementation approach

- BR-1: implement in Shared Angular UI.
  - Branch BR-1.Y: when The value is valid, The measurement is saved.
    - Coverage: DAB: covered, UI: covered
    - Evidence: EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
    - Evidence: EV-3 [code] DAB Repo/Handlers/CreateMeasurementHandler.cs — Handle: DAB handler validates with FluentValidation and saves
    - Evidence: EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
    - Acceptance criteria: AC-1
  - Branch BR-1.N: when The value is invalid, The save is rejected with a clear message.
    - Coverage: DAB: partial, UI: covered
    - Evidence: EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
    - Evidence: EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
    - Acceptance criteria: AC-2
- BR-2: implement in Shared Angular UI.

## Existing code references

- EV-1 [code] Legacy Repo/Plugins/MeasurementCreatePlugin.cs — Execute: Legacy plugin rejects an invalid measurement
- EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
- EV-3 [code] DAB Repo/Handlers/CreateMeasurementHandler.cs — Handle: DAB handler validates with FluentValidation and saves
- EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
- EV-6 [reach] DAB Repo/Program.cs — host: DAB host registers the handlers
- EV-7 [reach] UI Repo/src/app/measurement/measurement.service.ts — create: Shared UI posts to the configured API URL

## Dependencies

None.

## Validation requirements

- BR-1: positive, negative scenarios; enforced by application.
- BR-2: positive, negative scenarios; enforced by application.

## Test scenarios

- Verify AC-1 (positive)
- Verify AC-2 (negative)
- Verify AC-3 (positive)
- Verify AC-4 (negative)

## Business decisions

- DEC-1:  (Stated in the original request (Description))
- DEC-2: Reject it with a clear message (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.280Z (option A))
- DEC-3: All business units (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.358Z (option A))
- DEC-4: Yes, show it (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.423Z (option A))
- DEC-5: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.488Z (option A))
- DEC-6: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.553Z (option A))
- DEC-7: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-12T16:54:01.624Z (option A))

## Risks, open issues and assumptions

- BR-1: The audit-trail side effect of the legacy plugin is not verified (informational evidence gap; does not block the PBI)

## Related requirements owned by other PBIs

None.

## Approval

- Final user approval: Product owner, 2026-11-12T16:54:03.164Z (Approve & Generate in the PBI Builder wizard)
- PO/BA approval: not recorded by this tool; obtain it as your organization requires
- Technical approval: not recorded by this tool; obtain it as your organization requires
